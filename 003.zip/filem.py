import glob
import os
from kivymd.app import MDApp
from kivy.uix.scatter import Scatter
from kivymd.uix.imagelist import SmartTile
from kivy.core.image import Image as CoreImage
from kivy.uix.behaviors import ButtonBehavior
from kivymd.uix.behaviors import BackgroundColorBehavior
from kivy.uix.gridlayout import GridLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.lang.builder import Builder

kv = '''
<Gallery>:
	cols: 1
	size_hint: 1, None
	height: (225*6)+100
	MDLabel:
		text: "dimension: {} /n hbar: {}".format(str(selected.bbox), str(scroller.vbar))
		theme_text_color: 'Custom'
		text_color: (1,1,1,1)
		size_hint_y: None
		height: 100
	RelativeLayout:
		id: image_background
		canvas.after:
			Color:
				rgba: (1, 1, 1, .3)
			RoundedRectangle:
				pos: self.pos[0]+125, self.pos[1]+125
				size: 500, 500
				radius: (212.5, 212.5, 212.5, 212.5)
			
			Color:
				rgba: (.5, 0, 0, 0.4)
			Rectangle:
				pos: self.pos
				size: self.size
				
		ScatterImage:
			id: selected
			do_rotation: False
			allow_stretch: True
			
	ScrollView:
		id: scroller
		ImageHolder:
			id: image_holder
			canvas:
				Color:
					rgba: app.theme_cls.bg_dark
				Rectangle:
					pos: self.pos
					size: self.size
				
			cols: 1
			size_hint_y: None
			adaptive_height: True
			GridLayout:
				id: all_images
				size_hint: 1, None
				adaptive_height: True
				cols: 3
			MDRectangleFlatIconButton:
				icon: 'chevron-double-down'
				halign: 'center'
				size_hint: 1, None
				height: 100
				on_press:
					root.add_images()


<ScatterImage@Image+Scatter>

<GalleryImage>:
	allow_stretch: False
	lines: 2
	box_color: (0,0,0,0)
	
<ImageHolder@BackgroundColorBehavior+GridLayout>
	
'''
Builder.load_string(kv)

class GalleryImage(SmartTile, ButtonBehavior):
	def __init__(self, **kwargs):
		super(GalleryImage, self).__init__(**kwargs)
		
	def on_press(self):
		self.parent.parent.parent.parent.ids['selected'].source = self.source
			
		self.parent.parent.parent.parent.ids['selected'].size_hint = None, None
		
		self.parent.parent.parent.parent.ids['selected'].size = 700, 700
		

class Gallery(GridLayout):
#	dir = '/storage/emulated/0/Pictures/'
	dir = '/sdcard/'
	images = []
	
	def __init__(self, **kwargs):
		super(Gallery, self).__init__(**kwargs)
		
		for r, d, f in os.walk(self.dir):
		    for file in f:
		        if file.endswith(".png") or file.endswith(".jpg"):
		            self.images.append(os.path.join(r, file))
		self.images.sort(key= lambda x: os.path.getmtime(x), reverse=True)
		
		self.size_hint_y= None
		
		self.load_limit = 0
		self.add_images()
		
		
		
	def add_images(self):
		h = 225
		l = self.load_limit 
		
		for image in self.images[l: l+9]:
			self.load_limit = self.load_limit + 1
			self.ids['all_images'].add_widget(GalleryImage(source=image, size_hint= (None, None), size= (h, h)))
		
		l = self.load_limit /3
		self.ids['all_images'].height = h * l
		self.ids['image_holder'].height = h * l + 100
		
		
			
			
			
		
					
					

class myapp(MDApp):
	def build(self):
		self.theme_cls.theme_style = 'Dark'
		return Gallery()
		
myapp().run()
